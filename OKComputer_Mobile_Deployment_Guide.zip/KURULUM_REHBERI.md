# AS9100 QMS - Web Sunucu Kurulum Rehberi

## 📦 Paket İçeriği

```
as9100-qms-build.zip
├── index.html          # Ana sayfa (giriş noktası)
├── manifest.json       # PWA manifest dosyası
├── sw.js              # Service Worker (offline çalışma)
├── assets/            # CSS ve JS dosyaları
│   ├── index-xxx.js   # Uygulama kodu
│   └── index-xxx.css  # Stil dosyaları
└── icon-xxx.png       # Uygulama ikonları (72x72 - 512x512)
```

---

## 🚀 Kurulum Adımları

### 1. Dosyaları Yükleyin

#### cPanel / FTP ile Yükleme:

1. **Zip dosyasını bilgisayarınıza indirin**
2. **cPanel'e giriş yapın** veya **FTP istemcisi** kullanın
3. **public_html** klasörüne gidin (veya alt klasör oluşturun: `as9100`)
4. **Zip dosyasını yükleyin** ve **extract (çıkart)** yapın

```
public_html/
├── index.html
├── manifest.json
├── sw.js
├── assets/
└── icon-xxx.png
```

#### SSH / Terminal ile Yükleme:

```bash
# Web sunucunuza bağlanın
ssh kullaniciadi@sunucunuz.com

# Web dizinine gidin
cd /var/www/html
# veya
cd /home/kullaniciadi/public_html

# Zip dosyasını yükleyin (scp ile)
# Bilgisayarınızdan:
scp as9100-qms-build.zip kullaniciadi@sunucunuz.com:/var/www/html/

# Sunucuda çıkartın
unzip as9100-qms-build.zip

# Zip dosyasını silin (isteğe bağlı)
rm as9100-qms-build.zip

# Dosya izinlerini ayarlayın
chmod -R 755 .
```

---

### 2. Apache Yapılandırması (.htaccess)

**public_html/.htaccess** dosyası oluşturun veya düzenleyin:

```apache
# AS9100 QMS - Apache Yapılandırması

# Gzip sıkıştırma
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript application/json
</IfModule>

# Tarayıcı önbellekleme
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>

# SPA (Single Page Application) yönlendirme
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    
    # Var olan dosya ve klasörlere erişimi engelleme
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    
    # Tüm istekleri index.html'e yönlendir
    RewriteRule ^ index.html [L]
</IfModule>

# Güvenlik başlıkları
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
</IfModule>

# Service Worker için MIME tipi
AddType application/javascript .js
```

---

### 3. Nginx Yapılandırması

**nginx.conf** veya site yapılandırmanız:

```nginx
server {
    listen 80;
    server_name sizin-siteniz.com www.sizin-siteniz.com;
    root /var/www/html;
    index index.html;

    # Gzip sıkıştırma
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml;

    # Statik dosyalar için önbellek
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # SPA yönlendirme
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Güvenlik başlıkları
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

Nginx'i yeniden başlatın:
```bash
sudo systemctl restart nginx
```

---

### 4. SSL Sertifikası (HTTPS) - Önerilen

**Let's Encrypt ile ücretsiz SSL:**

```bash
# Certbot kurulumu
sudo apt-get install certbot python3-certbot-nginx

# Sertifika alma (Nginx)
sudo certbot --nginx -d sizin-siteniz.com -d www.sizin-siteniz.com

# Sertifika alma (Apache)
sudo certbot --apache -d sizin-siteniz.com -d www.sizin-siteniz.com
```

---

## 🔧 Sık Karşılaşılan Sorunlar

### 1. "404 Not Found" Hatası

**Çözüm:** .htaccess veya Nginx yapılandırmasını kontrol edin. SPA yönlendirme aktif olmalı.

### 2. Beyaz/Boş Sayfa

**Çözüm:**
- Tarayıcı konsolunu açın (F12) ve hataları kontrol edin
- Dosya izinlerini kontrol edin: `chmod -R 755 /var/www/html`
- assets klasörünün doğru yerde olduğundan emin olun

### 3. CSS/JS Yüklenmiyor

**Çözüm:**
- Dosya yollarını kontrol edin
- .htaccess gzip ayarlarını kontrol edin
- Tarayıcı önbelleğini temizleyin (Ctrl+Shift+R)

### 4. PWA Çalışmıyor

**Çözüm:**
- HTTPS zorunludur (Service Worker için)
- manifest.json ve sw.js dosyalarının erişilebilir olduğundan emin olun
- Tarayıcı konsolunda hataları kontrol edin

---

## 📁 Önerilen Dizin Yapısı

### Ana Dizine Kurulum:
```
/var/www/html/
├── index.html
├── manifest.json
├── sw.js
├── assets/
└── .htaccess
```

**URL:** `https://sizin-siteniz.com`

### Alt Klasöre Kurulum:
```
/var/www/html/as9100/
├── index.html
├── manifest.json
├── sw.js
├── assets/
└── .htaccess
```

**URL:** `https://sizin-siteniz.com/as9100/`

**Not:** Alt klasöre kurulum yaparsanız, `vite.config.ts` içindeki `base` ayarını değiştirmeniz gerekir:
```javascript
export default defineConfig({
  base: '/as9100/',
  // ...
});
```

---

## 🌐 Hosting Önerileri

### Ücretsiz Seçenekler:
| Platform | Özellikler |
|----------|------------|
| **Netlify** | Sürükle-bırak, otomatik HTTPS, PWA desteği |
| **Vercel** | Git entegrasyonu, hızlı dağıtım |
| **GitHub Pages** | Basit statik hosting |
| **Surge.sh** | Komut satırından deploy |

### Ücretli Seçenekler:
| Platform | Başlangıç Fiyatı |
|----------|------------------|
| **DigitalOcean** | $5/ay |
| **Linode** | $5/ay |
| **AWS S3 + CloudFront** | Kullanıma göre |
| **Cloudflare Pages** | Ücretsiz (limitsiz) |

---

## ✅ Kurulum Sonrası Kontrol Listesi

- [ ] Ana sayfa açılıyor mu? (`https://sizin-siteniz.com`)
- [ ] Menüler çalışıyor mu?
- [ ] Sayfalar arası geçişler sorunsuz mu?
- [ ] PWA olarak telefona eklenebiliyor mu?
- [ ] Offline mod çalışıyor mu?
- [ ] SSL/HTTPS aktif mi?

---

## 🆘 Destek

Sorun yaşarsanız:
1. Tarayıcı konsolunu kontrol edin (F12)
2. Sunucu loglarını inceleyin
3. Dosya izinlerini kontrol edin
4. .htaccess veya nginx.conf yapılandırmasını gözden geçirin

---

## 📞 İletişim

Kurulumla ilgili yardım için: [destek@sizin-siteniz.com]

---

**Kurulum Tarihi:** 2024
**Versiyon:** 1.0.0
**Lisans:** MIT
